BOX INTEGRATION SYSTEMS — EXPERIENCIA CORPORATIVA 3D

PÁGINAS
- index.html: inicio y visión global.
- empresa.html: empresa y valores.
- soluciones.html: hub de especialidades.
- energia.html: energía.
- servicios-obra.html: servicios en obra.
- telecomunicaciones.html: telecomunicaciones.
- movilidad-urbana.html: movilidad urbana.
- instalaciones.html: infraestructura industrial y logística.
- innovacion.html: I+D+i y publicaciones.
- calidad.html: política y compromisos de calidad.
- contacto.html: contacto.

INTERACCIONES
- Modelo modular 3D realizado en CSS 3D, manipulable mediante ratón o táctil.
- Hotspots explicativos y controles de vistas frontal, lateral y superior.
- Tarjetas con inclinación 3D, navegación translúcida, menús desplegables, transiciones de navegación y animaciones de entrada al hacer scroll.
- Diseño responsive y respeto a prefers-reduced-motion.

PUBLICACIÓN
Web estática sin compilación ni dependencias JS externas. Sube el contenido de esta carpeta a la raíz del repositorio GitHub Pages.

RECURSOS
Se reutilizan imágenes y logotipo alojados públicamente en boxis.es. Las figuras 3D del módulo son representaciones conceptuales CSS, no modelos CAD de un producto BOXIS.

FORMULARIO
El formulario usa mailto:press@boxis.es; no guarda ni envía datos a un servidor.

CONTENIDO
Los datos corporativos se han extraído de páginas públicas de BOXIS. La página de servicios en obra y la de telecomunicaciones presentan poca información específica; se ha evitado inventar especificaciones.
