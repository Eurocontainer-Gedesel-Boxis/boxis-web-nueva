BOX INTEGRATION SYSTEMS — NUEVA WEB CORPORATIVA

CONTENIDO
- index.html: estructura completa de la página.
- styles.css: estilos responsive y sistema visual.
- script.js: navegación móvil, navegación activa, animaciones de entrada y formulario mailto.
- .github/workflows/pages.yml: publicación automática en GitHub Pages cada vez que se actualice main.

VISTA PREVIA LOCAL
1. Descomprime la carpeta.
2. Abre index.html en un navegador moderno.

PUBLICACIÓN EN GITHUB PAGES
1. Crea un repositorio NUEVO y público llamado boxis-web-nueva.
2. Sube el contenido de esta carpeta a la raíz del repositorio (index.html debe quedar directamente en la raíz).
3. En GitHub abre Settings > Pages y selecciona "GitHub Actions" como fuente de publicación.
4. En Actions, ejecuta "Publish BOXIS website to GitHub Pages" si no se ejecuta automáticamente.
5. La dirección resultante será https://USUARIO.github.io/boxis-web-nueva/.

El workflow incluido automatiza las publicaciones posteriores cada vez que se hace push a main.

RECURSOS VISUALES
El logotipo y las imágenes insertadas se cargan desde los recursos públicos del sitio oficial boxis.es. Es necesaria conexión a Internet para visualizarlos. No he copiado imágenes de terceros identificadas en la web como material cedido por otras empresas.

FORMULARIO
El formulario prepara un correo dirigido a press@boxis.es mediante la aplicación de correo del visitante. No existe envío a servidor ni almacenamiento de datos.

NOTAS DE CONTENIDO
Los textos se han reorganizado a partir de las páginas públicas de BOXIS: inicio, quiénes somos, servicios, energía, telecomunicaciones, servicios en obra, movilidad urbana, instalaciones, dónde estamos, política de calidad, contacto, blog y perfiles corporativos. Se han evitado afirmaciones no respaldadas por esas fuentes.

El teléfono principal utilizado en la interfaz es +34 976 22 04 63, que aparece en la cabecera y página de contacto del sitio oficial. En otras páginas del dominio también aparece +34 976 107 525; conviene confirmar internamente cuál debe figurar como número comercial definitivo.
