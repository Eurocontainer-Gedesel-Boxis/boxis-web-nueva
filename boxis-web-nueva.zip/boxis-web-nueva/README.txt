BOX Integration Systems — propuesta de web corporativa multipágina

Incluye páginas separadas: Inicio, Empresa, Soluciones, Energía, Servicios en obra, Telecomunicaciones, Movilidad urbana, Instalaciones, I+D+i, Calidad, Dónde estamos, Sostenibilidad, Actualidad y Contacto.

Interacción: visor 3D WebGL procedimental (Three.js 0.180.0 desde jsDelivr), controles frontal/lateral/superior/reset, rotación con ratón o táctil, animación vinculada al scroll, tarjetas con profundidad, fondos con luz parallax y transiciones de página. Si WebGL o el motor CDN no están disponibles, se mantiene activo el modelo 3D CSS de reserva. Respeta prefers-reduced-motion.

La información corporativa se ha redactado a partir de páginas públicas de boxis.es. Las noticias y certificaciones históricas enlazan a sus artículos originales y conservan su fecha de publicación. El formulario de contacto abre un correo mailto; no almacena ni envía datos a un servidor.

Publicación: extraer el contenido de este ZIP y servir index.html como página raíz.
