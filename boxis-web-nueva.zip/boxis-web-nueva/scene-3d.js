import('https://cdn.jsdelivr.net/npm/three@0.180.0/build/three.module.js').then(THREE=>{
  const reduceMotion=window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  document.querySelectorAll('[data-model-stage]').forEach(stage=>{
    if(stage.dataset.webglReady==='true') return;
    const model=stage.querySelector('.modular-unit');
    if(!model) return;
    let renderer,scene,camera,group,frame,visible=true,pageVisible=!document.hidden,dragging=false,px=0,py=0;
    let targetX=.16,targetY=-.5,manualUntil=0,lastTime=0;
    try{
      renderer=new THREE.WebGLRenderer({alpha:true,antialias:true,powerPreference:'high-performance'});
      renderer.setPixelRatio(Math.min(window.devicePixelRatio||1,1.65));
      renderer.setSize(stage.clientWidth,stage.clientHeight,false);
      renderer.outputColorSpace=THREE.SRGBColorSpace;
      renderer.toneMapping=THREE.ACESFilmicToneMapping;
      renderer.toneMappingExposure=1.08;
      renderer.setClearColor(0x06121c,0);
      renderer.domElement.className='webgl-canvas';
      renderer.domElement.setAttribute('aria-hidden','true');
      stage.insertBefore(renderer.domElement,stage.firstChild);
      scene=new THREE.Scene();
      camera=new THREE.PerspectiveCamera(33,stage.clientWidth/stage.clientHeight,.1,100);
      camera.position.set(7.6,4.2,9.5); camera.lookAt(0,0,0);
      group=new THREE.Group(); scene.add(group);
      scene.add(new THREE.HemisphereLight(0xc6f4ff,0x07111c,1.3));
      const key=new THREE.DirectionalLight(0xe8fbff,2.5); key.position.set(-4,7,7); scene.add(key);
      const rim=new THREE.PointLight(0x37b9d8,38,13); rim.position.set(4,2,3); scene.add(rim);
      const fill=new THREE.PointLight(0x5e9bb5,23,12); fill.position.set(-5,1,-4); scene.add(fill);
      const warm=new THREE.PointLight(0xb9d8e2,9,8); warm.position.set(0,5,-1); scene.add(warm);

      const kind=model.dataset.kind||'energy';
      const faceColor=kind==='mobility'?0x1b3540:(kind==='telecom'?0x173448:0x162e3d);
      const edgeColor=kind==='mobility'?0x8be4ce:0x8ed9e8;
      const bodyMat=new THREE.MeshPhysicalMaterial({color:faceColor,metalness:.72,roughness:.36,clearcoat:.48,clearcoatRoughness:.3});
      const panelMat=new THREE.MeshPhysicalMaterial({color:0x0c1c28,metalness:.65,roughness:.42,clearcoat:.35});
      const edgeMat=new THREE.MeshStandardMaterial({color:edgeColor,metalness:.78,roughness:.28});
      const darkMat=new THREE.MeshStandardMaterial({color:0x07131d,metalness:.55,roughness:.5});
      const ventMat=new THREE.MeshStandardMaterial({color:0x6c8b99,metalness:.8,roughness:.34});
      const glowMat=new THREE.MeshStandardMaterial({color:kind==='mobility'?0x78edbe:0x8cf0f5,emissive:kind==='mobility'?0x24b97b:0x1f9caf,emissiveIntensity:2.4});
      const addBox=(w,h,d,x,y,z,mat,parent=group)=>{const m=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),mat);m.position.set(x,y,z);m.castShadow=true;m.receiveShadow=true;parent.add(m);return m;};
      const addCylinder=(r1,r2,h,x,y,z,mat,rx=0,parent=group)=>{const m=new THREE.Mesh(new THREE.CylinderGeometry(r1,r2,h,24),mat);m.position.set(x,y,z);m.rotation.x=rx;parent.add(m);return m;};
      // Main enclosure: seven metres wide in the illustrative, not-to-scale concept model.
      addBox(6.45,2.28,2.42,0,0,0,bodyMat);
      // Lower chassis and feet.
      addBox(6.64,.15,2.58,0,-1.22,0,edgeMat);
      addBox(6.5,.12,2.46,0,-1.11,0,darkMat);
      for(const x of [-2.85,2.85]) for(const z of [-.92,.92]){
        addBox(.34,.22,.42,x,-1.39,z,ventMat);
        addBox(.22,.14,.3,x,-1.54,z,darkMat);
      }
      // Front face: perimeter rails, technical doors, gaskets, hinges and handles.
      for(const x of [-3.18,3.18]) addBox(.075,2.12,.085,x,0,1.245,edgeMat);
      for(const y of [-1.04,1.04]) addBox(6.35,.055,.08,0,y,1.25,edgeMat);
      addBox(2.05,1.78,.055,-1.85,-.01,1.255,panelMat);
      addBox(1.96,1.78,.055,.22,-.01,1.255,panelMat);
      addBox(1.34,1.78,.055,2.0,-.01,1.255,darkMat);
      // Door separators and horizontal service rail.
      for(const x of [-2.88,-.79,1.22,2.69]) addBox(.035,1.8,.08,x,-.01,1.30,edgeMat);
      addBox(6.0,.025,.035,0,-.87,1.31,ventMat);
      // Front ventilation bank, individual fins and end frame.
      addBox(1.12,1.32,.075,2.0,.0,1.34,darkMat);
      for(let i=0;i<17;i++) addBox(1.02,.025,.045,2.0,-.57+i*.071,1.395,ventMat);
      // Technical handles and hinge blocks.
      for(const x of [-2.74,-.91,.98]){
        addBox(.055,.32,.09,x,.04,1.39,edgeMat);
        addBox(.12,.055,.07,x,.2,1.4,ventMat);
        addBox(.12,.055,.07,x,-.12,1.4,ventMat);
      }
      // Brand plate and status light.
      addBox(.92,.22,.045,-2.15,.78,1.31,darkMat);
      addBox(.55,.03,.02,-2.15,.78,1.34,edgeMat);
      addBox(.25,.1,.04,2.86,.78,1.32,glowMat);
      // Side service panel and side ventilation (right face).
      for(let i=0;i<13;i++) addBox(.055,1.85,.04,3.27,-.92+i*.15,.15,ventMat);
      addBox(.08,1.95,2.18,3.22,0,0,edgeMat);
      addBox(.045,1.77,2.05,3.27,0,0,bodyMat);
      // Side louvre strips sit on the outward side plane.
      for(let i=0;i<14;i++) addBox(.035,.045,1.24,3.30,-.68+i*.105,-.22,ventMat);
      // Roof skin, transverse rails, lift points, cooling units and cable glands.
      addBox(6.42,.10,2.40,0,1.19,0,edgeMat);
      for(const x of [-2.75,-1.35,.05,1.45,2.75]) addBox(.055,.075,2.22,x,1.27,0,ventMat);
      for(const x of [-2.5,2.5]){
        addCylinder(.12,.12,.11,x,1.33,-.9,edgeMat);
        addCylinder(.12,.12,.11,x,1.33,.9,edgeMat);
      }
      // Two roof ventilation cassettes with louvres.
      for(const x of [-1.45,1.65]){
        addBox(1.0,.22,.78,x,1.37,-.25,darkMat);
        addBox(.92,.035,.68,x,1.5,-.25,ventMat);
        for(let j=0;j<7;j++) addBox(.84,.025,.045,x,1.53,-.52+j*.09,edgeMat);
      }
      // Rear service relief and subtle corner posts.
      for(const x of [-3.15,3.15]) addBox(.08,2.13,.08,x,0,-1.23,ventMat);
      // Floating plinth ring and a technical ground grid.
      const halo=new THREE.Mesh(new THREE.TorusGeometry(3.65,.012,8,120),new THREE.MeshBasicMaterial({color:0x4dbbd4,transparent:true,opacity:.38}));
      halo.rotation.x=Math.PI/2; halo.position.y=-1.62; group.add(halo);
      const halo2=new THREE.Mesh(new THREE.TorusGeometry(4.15,.006,6,120),new THREE.MeshBasicMaterial({color:0x9debf2,transparent:true,opacity:.18}));
      halo2.rotation.x=Math.PI/2; halo2.position.y=-1.63; group.add(halo2);
      // Small category-specific details.
      if(kind==='telecom'){
        for(let rack=0;rack<4;rack++){
          addBox(.32,1.38,.06,-2.5+rack*.38,-.02,1.405,edgeMat);
          for(let row=0;row<8;row++) addBox(.26,.04,.035,-2.5+rack*.38,-.58+row*.16,1.45,ventMat);
        }
      } else if(kind==='mobility'){
        for(let i=0;i<3;i++){
          addBox(.33,.76,.08,-2.35+i*.58,-.08,1.42,panelMat);
          addBox(.08,.08,.06,-2.35+i*.58,.4,1.48,glowMat);
        }
      }

      const resize=()=>{
        const w=Math.max(1,stage.clientWidth),h=Math.max(1,stage.clientHeight);
        camera.aspect=w/h;camera.updateProjectionMatrix();renderer.setSize(w,h,false);
        const scale=Math.min(1.08,Math.max(.68,w/620));group.scale.setScalar(scale);
      };
      const ro=new ResizeObserver(resize);ro.observe(stage);resize();
      const setView=(view)=>{
        manualUntil=performance.now()+5000;
        if(view==='front'){targetX=0;targetY=0;}
        else if(view==='side'){targetX=.02;targetY=-Math.PI/2;}
        else if(view==='top'){targetX=-.93;targetY=-.48;}
        else {targetX=.16;targetY=-.5;}
        stage.querySelectorAll('[data-view]').forEach(b=>b.classList.toggle('active',b.dataset.view===view));
      };
      stage.querySelectorAll('[data-view]').forEach(b=>b.addEventListener('click',()=>setView(b.dataset.view)));
      stage.addEventListener('pointerdown',e=>{
        if(e.target.closest('button')) return;
        dragging=true;px=e.clientX;py=e.clientY;manualUntil=performance.now()+7000;
        stage.setPointerCapture?.(e.pointerId);
      });
      stage.addEventListener('pointermove',e=>{
        if(dragging){const dx=e.clientX-px,dy=e.clientY-py;px=e.clientX;py=e.clientY;targetY+=dx*.008;targetX=Math.max(-1.15,Math.min(.85,targetX+dy*.006));manualUntil=performance.now()+7000;}
        else if(e.pointerType!=='touch'&&!reduceMotion){const r=stage.getBoundingClientRect();const nx=(e.clientX-r.left)/r.width-.5;const ny=(e.clientY-r.top)/r.height-.5;stage.style.setProperty('--mx',`${(nx+.5)*100}%`);stage.style.setProperty('--my',`${(ny+.5)*100}%`);}
      });
      const endDrag=()=>{dragging=false;};stage.addEventListener('pointerup',endDrag);stage.addEventListener('pointercancel',endDrag);
      const stop=()=>{if(frame){cancelAnimationFrame(frame);frame=null;}};
      const io=new IntersectionObserver(entries=>{visible=entries.some(x=>x.isIntersecting);if(visible&&pageVisible&&!frame)animate();else if(!visible)stop();},{threshold:.02});io.observe(stage);
      const animate=(time=0)=>{
        frame=requestAnimationFrame(animate);
        const dt=Math.min(.04,(time-lastTime)/1000||0);lastTime=time;
        if(!visible||!pageVisible){stop();return;}
        if(!reduceMotion&&performance.now()>manualUntil&&!dragging){
          const rect=stage.getBoundingClientRect();const progress=Math.max(0,Math.min(1,(window.innerHeight-rect.top)/(window.innerHeight+rect.height)));
          targetY=-.5+(progress-.45)*.52;
          targetX=.16+(progress-.45)*.18;
        }
        group.rotation.y+=(targetY-group.rotation.y)*Math.min(1,dt*5.5);
        group.rotation.x+=(targetX-group.rotation.x)*Math.min(1,dt*5.5);
        if(!reduceMotion&&performance.now()>manualUntil&&!dragging) group.rotation.z=Math.sin(time*.00035)*.012;
        renderer.render(scene,camera);
      };
      stage.dataset.webglReady='true';stage.classList.add('has-webgl');
      model.setAttribute('aria-hidden','true');
      animate();
      document.addEventListener('visibilitychange',()=>{pageVisible=!document.hidden;if(pageVisible&&visible&&!frame)animate();else if(!pageVisible)stop();});
    }catch(err){
      if(renderer){renderer.dispose();renderer.domElement.remove();}
      stage.classList.remove('has-webgl');
      console.warn('BOXIS 3D viewer: CSS fallback active.',err);
    }
  });
}).catch(err=>console.warn('BOXIS 3D engine unavailable; using the CSS 3D model.',err));
