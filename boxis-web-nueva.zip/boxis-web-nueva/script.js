(() => {
  const menuButton = document.querySelector('.menu-toggle');
  const nav = document.querySelector('.main-nav');

  if (menuButton && nav) {
    menuButton.addEventListener('click', () => {
      const open = nav.classList.toggle('is-open');
      menuButton.setAttribute('aria-expanded', String(open));
      menuButton.setAttribute('aria-label', open ? 'Cerrar menú' : 'Abrir menú');
    });
    nav.querySelectorAll('a').forEach(link => link.addEventListener('click', () => {
      nav.classList.remove('is-open');
      menuButton.setAttribute('aria-expanded', 'false');
      menuButton.setAttribute('aria-label', 'Abrir menú');
    }));
  }

  const navLinks = [...document.querySelectorAll('.main-nav a[href^="#"]')];
  const observedSections = navLinks
    .map(link => document.querySelector(link.getAttribute('href')))
    .filter(Boolean);
  if ('IntersectionObserver' in window && observedSections.length) {
    const navObserver = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (!entry.isIntersecting) return;
        navLinks.forEach(link => {
          link.classList.toggle('active', link.getAttribute('href') === `#${entry.target.id}`);
        });
      });
    }, { rootMargin: '-28% 0px -62% 0px', threshold: 0 });
    observedSections.forEach(section => navObserver.observe(section));
  }

  const revealTargets = document.querySelectorAll('.section-head, .company-layout, .solution-card, .energy-item, .sector-row, .process-step, .facilities-panel, .facility-bottom-item, .location-grid, .logistics-strip, .innovation-grid, .quality-point, .history-list article, .contact-shell');
  if ('IntersectionObserver' in window) {
    const revealObserver = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          revealObserver.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12 });
    revealTargets.forEach((element, index) => {
      element.classList.add('reveal');
      element.style.transitionDelay = `${Math.min(index % 4, 3) * 65}ms`;
      revealObserver.observe(element);
    });
  }

  const year = document.getElementById('year');
  if (year) year.textContent = new Date().getFullYear();

  const form = document.getElementById('contact-form');
  if (form) {
    form.addEventListener('submit', event => {
      event.preventDefault();
      if (!form.reportValidity()) return;
      const data = new FormData(form);
      const subject = `Consulta desde la web BOXIS — ${String(data.get('company') || data.get('name')).trim()}`;
      const body = [
        `Nombre: ${data.get('name')}`,
        `Correo: ${data.get('email')}`,
        `Teléfono: ${data.get('phone') || 'No indicado'}`,
        `Empresa: ${data.get('company') || 'No indicada'}`,
        '',
        'Proyecto:',
        data.get('message')
      ].join('\n');
      window.location.href = `mailto:press@boxis.es?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
    });
  }
})();
