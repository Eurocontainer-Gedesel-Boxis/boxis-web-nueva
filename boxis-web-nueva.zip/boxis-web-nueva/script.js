(() => {
  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const header = document.querySelector('.site-header');
  const progress = document.querySelector('.top-progress span');
  const topBtn = document.querySelector('.back-top');
  const toggle = document.querySelector('.menu-toggle');
  const nav = document.querySelector('.main-nav');
  let pointerFrame = 0;
  document.addEventListener('pointermove', e => {
    if (e.pointerType === 'touch' || reduceMotion || pointerFrame) return;
    pointerFrame = requestAnimationFrame(() => {
      document.documentElement.style.setProperty('--mx', `${(e.clientX / Math.max(1, window.innerWidth))*100}%`);
      document.documentElement.style.setProperty('--my', `${(e.clientY / Math.max(1, window.innerHeight))*100}%`);
      pointerFrame = 0;
    });
  }, {passive:true});

  const onScroll = () => {
    const y = window.scrollY || 0;
    if (header) header.classList.toggle('scrolled', y > 24);
    if (topBtn) topBtn.classList.toggle('visible', y > 500);
    if (progress) {
      const d = document.documentElement.scrollHeight - window.innerHeight;
      progress.style.width = `${d > 0 ? (y / d) * 100 : 0}%`;
    }
  };
  window.addEventListener('scroll', onScroll, {passive:true}); onScroll();

  if (toggle && nav) {
    toggle.addEventListener('click', () => {
      const open = nav.classList.toggle('open');
      toggle.setAttribute('aria-expanded', String(open));
    });
    nav.querySelectorAll('a').forEach(a => a.addEventListener('click', () => {
      nav.classList.remove('open'); toggle.setAttribute('aria-expanded','false');
    }));
    nav.querySelectorAll('.nav-drop > button').forEach(btn => btn.addEventListener('click', () => {
      const parent = btn.closest('.nav-drop');
      const opened = parent.classList.toggle('open');
      btn.setAttribute('aria-expanded', String(opened));
    }));
  }

  if ('IntersectionObserver' in window && !reduceMotion) {
    const io = new IntersectionObserver(entries => entries.forEach(entry => {
      if (entry.isIntersecting) { entry.target.classList.add('in-view'); io.unobserve(entry.target); }
    }), {threshold:.11, rootMargin:'0px 0px -35px 0px'});
    document.querySelectorAll('.reveal').forEach(el => io.observe(el));
  } else document.querySelectorAll('.reveal').forEach(el => el.classList.add('in-view'));

  // Subtle, restrained 3D pointer response for cards and images.
  const tiltEls = document.querySelectorAll('[data-tilt]');
  tiltEls.forEach(el => {
    el.addEventListener('pointermove', e => {
      if (reduceMotion || e.pointerType === 'touch') return;
      const r = el.getBoundingClientRect();
      const x = (e.clientX - r.left) / r.width;
      const y = (e.clientY - r.top) / r.height;
      const rx = (0.5 - y) * 5.5;
      const ry = (x - 0.5) * 7;
      el.style.transform = `perspective(1000px) rotateX(${rx}deg) rotateY(${ry}deg) translateY(-2px)`;
      el.style.setProperty('--px', `${x*100}%`); el.style.setProperty('--py', `${y*100}%`);
    });
    el.addEventListener('pointerleave', () => { el.style.transform = ''; });
  });

  // Draggable CSS 3D unit; no external 3D runtime or heavy model download.
  document.querySelectorAll('[data-model-stage]').forEach(stage => {
    const model = stage.querySelector('.modular-unit');
    if (!model) return;
    let rx = -18, ry = -32, down = false, sx = 0, sy = 0, startX = 0, startY = 0;
    let manualUntil = 0;
    const set = () => { model.style.setProperty('--rx', `${rx}deg`); model.style.setProperty('--ry', `${ry}deg`); };
    const scrollPose = () => {
      if (down || performance.now() < manualUntil || stage.classList.contains('has-webgl') || reduceMotion) return;
      const rect = stage.getBoundingClientRect();
      const progress = Math.max(0, Math.min(1, (window.innerHeight - rect.top) / (window.innerHeight + rect.height)));
      model.style.setProperty('--rx', `${-18 + (progress-.45)*10}deg`);
      model.style.setProperty('--ry', `${-32 + (progress-.45)*42}deg`);
    };
    window.addEventListener('scroll', scrollPose, {passive:true}); scrollPose();
    stage.addEventListener('pointerdown', e => {
      if (e.target.closest('button')) return;
      down = true; sx = e.clientX; sy = e.clientY; startX = ry; startY = rx;
      stage.setPointerCapture?.(e.pointerId);
    });
    stage.addEventListener('pointermove', e => {
      if (!down) {
        manualUntil = performance.now() + 900;
        if (reduceMotion || e.pointerType === 'touch') return;
        const r = stage.getBoundingClientRect();
        const px = (e.clientX-r.left)/r.width - .5;
        const py = (e.clientY-r.top)/r.height - .5;
        model.style.setProperty('--rx', `${-18-py*7}deg`);
        model.style.setProperty('--ry', `${-32+px*10}deg`);
        return;
      }
      manualUntil = performance.now() + 2500;
      ry = Math.max(-70, Math.min(20, startX + (e.clientX-sx)*.32));
      rx = Math.max(-42, Math.min(8, startY - (e.clientY-sy)*.22)); set();
    });
    const up = () => { down = false; };
    stage.addEventListener('pointerup', up); stage.addEventListener('pointercancel', up);
    stage.querySelectorAll('[data-view]').forEach(btn => btn.addEventListener('click', () => {
      const view = btn.dataset.view;
      if (view === 'front') { rx=-2; ry=0; }
      if (view === 'side') { rx=-3; ry=-78; }
      if (view === 'top') { rx=28; ry=-30; }
      if (view === 'reset') { rx=-18; ry=-32; }
      manualUntil = performance.now() + 3000;
      set(); stage.querySelectorAll('[data-view]').forEach(b=>b.classList.toggle('active',b===btn));
    }));
    set();
  });

  // Buttons get a tiny pointer-driven depth response; touch and reduced-motion stay calm.
  document.querySelectorAll('.button').forEach(btn => {
    btn.addEventListener('pointermove', e => {
      if (reduceMotion || e.pointerType === 'touch') return;
      const r = btn.getBoundingClientRect();
      const x = (e.clientX-r.left)/r.width-.5, y=(e.clientY-r.top)/r.height-.5;
      btn.style.setProperty('--btn-rx', `${-y*4}deg`);
      btn.style.setProperty('--btn-ry', `${x*5}deg`);
    });
    btn.addEventListener('pointerleave', () => { btn.style.setProperty('--btn-rx','0deg'); btn.style.setProperty('--btn-ry','0deg'); });
  });

  // Hotspot panels disclose component information without filling the screen.
  document.querySelectorAll('[data-hotspot]').forEach(btn => btn.addEventListener('click', () => {
    const stage = btn.closest('[data-model-stage]');
    const panel = stage?.querySelector('.hotspot-readout');
    if (!panel) return;
    const items = {
      energy: ['Integración modular','Equipos de generación, transformación, control o almacenamiento coordinados en una misma solución.'],
      access: ['Acceso técnico','Disposición de puertas y registros pensada para facilitar instalación, operación y mantenimiento.'],
      ventilation: ['Ventilación y servicio','Elementos de ventilación representados de forma conceptual; la configuración real depende de cada ingeniería.']
    };
    const item = items[btn.dataset.hotspot] || items.energy;
    panel.querySelector('strong').textContent = item[0]; panel.querySelector('p').textContent = item[1]; panel.classList.add('active');
    stage.querySelectorAll('[data-hotspot]').forEach(b=>b.classList.toggle('active',b===btn));
  }));

  // Small tabs used on sector pages.
  document.querySelectorAll('[data-tabs]').forEach(group => {
    const buttons = group.querySelectorAll('[role="tab"]');
    const panels = group.querySelectorAll('[role="tabpanel"]');
    buttons.forEach(btn => btn.addEventListener('click', () => {
      buttons.forEach(b => {b.setAttribute('aria-selected', String(b===btn)); b.tabIndex = b===btn ? 0 : -1;});
      panels.forEach(p => p.hidden = p.id !== btn.getAttribute('aria-controls'));
    }));
  });

  const contactForm = document.querySelector('[data-contact-form]');
  if (contactForm) contactForm.addEventListener('submit', e => {
    e.preventDefault();
    const data = new FormData(contactForm);
    const subject = encodeURIComponent(`Consulta web BOXIS — ${data.get('company') || data.get('name') || 'Nuevo proyecto'}`);
    const body = encodeURIComponent(`Nombre: ${data.get('name')}\nEmpresa: ${data.get('company')}\nCorreo: ${data.get('email')}\nTeléfono: ${data.get('phone')}\n\nProyecto:\n${data.get('message')}`);
    const status = contactForm.querySelector('.form-status');
    if (status) status.textContent = 'Se abrirá tu aplicación de correo para revisar y enviar el mensaje.';
    window.location.href = `mailto:press@boxis.es?subject=${subject}&body=${body}`;
  });
  if (topBtn) topBtn.addEventListener('click', () => window.scrollTo({top:0,behavior:reduceMotion?'auto':'smooth'}));

  // Keep in-page internal links soft when supported; native navigation remains the fallback.
  document.querySelectorAll('a[href$=".html"]').forEach(a => {
    a.addEventListener('click', e => {
      if (e.metaKey || e.ctrlKey || e.shiftKey || e.altKey || !document.startViewTransition) return;
      // Native multi-document view transitions are enabled by CSS where supported.
    });
  });
})();
